# IOKing V3 — Android

Jeu de stratégie original, gratuit au lancement.

- Application Android native
- Jeu contre une IA simple
- Mode deux joueurs prévu dans l'interface
- Plateau 10×10
- Aucun paiement ni publicité dans cette version
- Build GitHub Actions inclus

Pour produire l'APK : le dépôt doit contenir tous les fichiers du projet, puis lancer l'action **Build IOKing APK**.
