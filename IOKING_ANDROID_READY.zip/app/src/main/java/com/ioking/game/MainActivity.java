
package com.ioking.game;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.content.*;
import java.util.*;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(new GameView(this));
    }

    static class GameView extends View {
        Paint p = new Paint(3);
        Paint text = new Paint(3);
        int n = 10;
        int[][] board = new int[n][n];
        int selectedR=-1, selectedC=-1;
        boolean whiteTurn=true, vsAI=true, twoPlayer=false;
        Random rnd=new Random();

        GameView(Context c) {
            super(c);
            text.setTypeface(Typeface.create("sans", Typeface.BOLD));
            reset();
        }

        void reset() {
            for(int r=0;r<n;r++) Arrays.fill(board[r],0);
            // Custom IOKing starting formation
            int[] back={2,3,4,5,1,5,4,3,2,2};
            for(int c=0;c<n;c++){ board[0][c]=back[c]; board[1][c]=6; board[8][c]=-6; board[9][c]=-back[c]; }
            whiteTurn=true; selectedR=selectedC=-1; invalidate();
        }

        protected void onDraw(Canvas c) {
            super.onDraw(c);
            int w=getWidth(), h=getHeight();
            c.drawColor(Color.rgb(17,19,24));
            text.setColor(Color.WHITE); text.setTextAlign(Paint.Align.CENTER);
            text.setTextSize(Math.max(28,w/15f)); c.drawText("IOking",w/2f,48,text);
            text.setTextSize(14); c.drawText(vsAI?"Joueur vs IA":"Deux joueurs",w/2f,72,text);

            float top=95, size=Math.min(w-28,(h-145)/1.0f), cell=size/n, left=(w-size)/2f;
            for(int r=0;r<n;r++) for(int col=0;col<n;col++){
                p.setColor(((r+col)&1)==0?Color.rgb(232,224,205):Color.rgb(101,125,92));
                c.drawRect(left+col*cell,top+r*cell,left+(col+1)*cell,top+(r+1)*cell,p);
                if((r==4&&col==4)||(r==5&&col==5)||(r==4&&col==5)||(r==5&&col==4)){
                    p.setColor(Color.argb(70,120,80,210)); c.drawCircle(left+(col+.5f)*cell,top+(r+.5f)*cell,cell*.28f,p);
                }
                if(r==selectedR&&col==selectedC){
                    p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(5); p.setColor(Color.WHITE);
                    c.drawRect(left+col*cell+3,top+r*cell+3,left+(col+1)*cell-3,top+(r+1)*cell-3,p); p.setStyle(Paint.Style.FILL);
                }
                int v=board[r][col]; if(v!=0) drawPiece(c,v,left+col*cell,top+r*cell,cell);
            }
            text.setTextSize(15);
            text.setColor(Color.WHITE);
            c.drawText(whiteTurn?"Tour des blancs":"Tour des noirs",w/2f,top+size+30,text);
            text.setTextSize(13);
            c.drawText("Touchez une pièce puis une case • ✦ = case spéciale",w/2f,top+size+52,text);
        }

        void drawPiece(Canvas c,int v,float x,float y,float s){
            p.setColor(v>0?Color.rgb(245,245,245):Color.rgb(35,35,40));
            p.setShadowLayer(4,0,2,Color.BLACK); setLayerType(View.LAYER_TYPE_SOFTWARE,p);
            c.drawCircle(x+s/2,y+s/2,s*.32f,p); p.clearShadowLayer();
            text.setColor(v>0?Color.rgb(30,30,30):Color.WHITE); text.setTextSize(s*.28f);
            String[] names={"","C","B","A","E","O","S"};
            c.drawText(names[Math.abs(v)],x+s/2,y+s*.60f,text);
        }

        public boolean onTouchEvent(android.view.MotionEvent e){
            if(e.getAction()!=MotionEvent.ACTION_UP) return true;
            float top=95, size=Math.min(getWidth()-28,(getHeight()-145)), cell=size/n, left=(getWidth()-size)/2f;
            float x=e.getX(), y=e.getY();
            if(y<top||x<left||x>=left+size||y>=top+size) return true;
            int col=(int)((x-left)/cell), row=(int)((y-top)/cell);
            int v=board[row][col];
            if(selectedR<0){
                if(v!=0 && ((v>0)==whiteTurn || twoPlayer)){selectedR=row;selectedC=col;invalidate();}
            } else {
                if(row==selectedR&&col==selectedC){selectedR=selectedC=-1;invalidate();return true;}
                if(v==0 || (v>0)!= (board[selectedR][selectedC]>0)){
                    board[row][col]=board[selectedR][selectedC]; board[selectedR][selectedC]=0;
                    selectedR=selectedC=-1; whiteTurn=!whiteTurn; invalidate();
                    if(vsAI && !whiteTurn) postDelayed(()->aiMove(),350);
                } else { selectedR=row; selectedC=col; invalidate(); }
            }
            return true;
        }

        void aiMove(){
            ArrayList<int[]> pieces=new ArrayList<>(), moves=new ArrayList<>();
            for(int r=0;r<n;r++) for(int c=0;c<n;c++) if(board[r][c]<0){
                pieces.add(new int[]{r,c});
                int[][] d={{1,0},{-1,0},{0,1},{0,-1},{1,1},{1,-1},{-1,1},{-1,-1}};
                for(int[] z:d){int rr=r+z[0],cc=c+z[1]; if(rr>=0&&rr<n&&cc>=0&&cc<n&&(board[rr][cc]>=0)) moves.add(new int[]{r,c,rr,cc});}
            }
            if(!moves.isEmpty()){
                int[] m=moves.get(rnd.nextInt(moves.size()));
                board[m[2]][m[3]]=board[m[0]][m[1]]; board[m[0]][m[1]]=0;
            }
            whiteTurn=true; invalidate();
        }
    }
}
