# IOKing V6

Version Android du jeu IOKing avec :
- partie hors ligne contre IA
- partie hors ligne à deux joueurs
- partie en ligne P2P via PeerJS (code de joueur à partager)
- profil persistant : victoires, défaites, points et rang
- victoire = +10 points ; défaite = +2 points
- rangs : Débutant, Normal, Intermédiaire, Difficile, Maître, Grand maître, Stratège, Maître stratège
- icône officielle IOKing V6 intégrée

## Construire l'APK
Le dépôt est prêt pour GitHub Actions. Le workflow `.github/workflows/build-apk.yml` lance `assembleDebug` et publie l'APK.

## Jeu en ligne
La connexion P2P nécessite Internet et utilise le service de signalisation PeerJS chargé depuis un CDN. Le code affiché dans « Créer une partie » doit être partagé avec l'adversaire, qui le saisit dans « Rejoindre une partie ».
