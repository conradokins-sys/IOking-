package com.ioking.game;
import android.app.Activity; import android.os.Bundle; import android.webkit.WebView; import android.webkit.WebSettings; import android.webkit.WebViewClient;
public class MainActivity extends Activity {
 public void onCreate(Bundle b){super.onCreate(b); WebView v=new WebView(this); WebSettings s=v.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); v.setWebViewClient(new WebViewClient()); v.loadUrl("file:///android_asset/index.html"); setContentView(v);}
}